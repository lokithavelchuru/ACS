console.log("Start")
 
 for (let i = 0; i < 20; i++) {
   console.log(i)
 }
 console.log("End")