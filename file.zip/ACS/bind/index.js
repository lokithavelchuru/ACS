var person = {  
    name: "James Smith",
    hello: function(thing) {
      console.log(this.name + " ," + thing);
    }
  }
  
  person.hello("world");  
  var helloFunc = person.hello.bind({ name: "Jim Smith" });
  helloFunc("world");  