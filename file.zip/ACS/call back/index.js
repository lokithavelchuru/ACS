function sum(num1,num2){
    return num1+num2
 }
 function calculate(num1,num2,sum){ 
     if(typeof sum=='function'){
        return sum(num1,num2);
 }
  }
 var result = calculate(5,6,sum);
 console.log(result);
  
