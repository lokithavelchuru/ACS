
let a = "hiii";
 setInterval(()=>alert(a),2000);
