/*let animal = {
  eats: true
};
let rabbit = {
  jumps: true
};ng

rabbit.__proto__ = animal;
console.log(rabbit.eats);
console.log(rabbit.jumps);*/

/*let animal={
  eats:true,
  Walk(){
    console.log("is walking");
  }
};
let rabbit={
  jumps:true,
  __proto__:animal
};
rabbit.Walk();*/

/*let animal={
  eats:true,
  walk(){
    console.log("is walking");
    console.log("is sleeping");
  }
};
let rabbit={
   jumps:true,
   __proto__ :animal
};
let  fox={
  sleep:true,
  __proto__:rabbit
};
fox.walk();
console.log(fox.jumps);*/

/*let animal = {
  eats: true
};

let rabbit = {
  jumps: true,
  __proto__: animal
};

for(let prop in rabbit) {
  let isOwn = rabbit.hasOwnProperty(prop);

  if (isOwn) {
    alert("our property"); 
  } else {
    alert("inherited property"); 
  }
}*/
window.onload =function(){
let menu = document.querySelector('#menu');

menu.addEventListener('click', (event) => {
    let target = event.target;

    switch(target.id) {
        case 'home':
            console.log('Home menu item was clicked');
            break;
        case 'dashboard':
            console.log('Dashboard menu item was clicked');
            break;
        case 'report':
            console.log('Report menu item was clicked');
            break;
    }
  });
}




  