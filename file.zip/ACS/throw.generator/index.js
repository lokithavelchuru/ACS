function* gen() {
    while(true) {
      try {
         yield 42;
      } catch(e) {
        console.log('Error caught!');
      }
    }
  }
  
  const g = gen();
  console.log(g.next());
  console.log(g.return());
  console.log(g.throw(new Error('Something went wrong')));
  