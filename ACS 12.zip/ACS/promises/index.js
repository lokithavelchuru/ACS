let pro;
let prom = new Promise(function (resolve, reject) {
 setTimeout(() => {
 if (pro==false) {
 resolve("I given party to friend");
 } else {
 reject("I am not given party to friends");
 }
 }, 1000);
});
console.log(prom);



