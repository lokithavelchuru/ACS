/*function sayHello() {
    alert('Hello');
  }
  setTimeout(sayHello, 1000);*/

  function sayhi(wish,message){
      console.log("good morning");
      alert(wish+','+message);
  }
  setTimeout(sayhi,2000,"hii","loki");
