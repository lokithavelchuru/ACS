/*function codeHoist(){
	a = 10;
	let b = 50;
}
codeHoist();

console.log(a); 
console.log(b); */

/*function fun(){
	var name = 'Mukul Latiyan';
	console.log(name); 
}
fun();*/

console.log(num); laration
var num; 
num = 6; 
console.log(num);




