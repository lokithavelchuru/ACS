console.log("Start")
 
setTimeout(()=>{
 console.log("Middle")
 }, 1000)
 
 console.log("End")