// let i = 0;

// let start = Date.now();

// function count() {
//     for (let j = 0; j < 1e9; j++) {
//     i++;
//   }

//   alert("Done in " + (Date.now() - start) + 'ms');
// }

// count();

// to overcome the heavy task
let i = 0;

let start = Date.now();

function count() {
    do {
    i++;
  } while (i % 1e6 != 0);

  if (i == 1e9) {
    alert("Done in " + (Date.now() - start) + 'ms');
  } else {
    setTimeout(count); 
  }

}

count();